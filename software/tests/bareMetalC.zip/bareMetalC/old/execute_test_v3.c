#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#ifndef BAREMETAL
#include <sys/mman.h>
#endif
#include "include/rocc.h"
#include "include/ISA.h"

#define sizeofBank 1024
#define in_port0 1
#define in_port1 0
#define in_port2 2
#define out_port 5
#define cfg_port 8
#define config_num 31

struct config
{
    unsigned short int cfg_data1;
    unsigned short int cfg_data2;
    unsigned short int cfg_base_addr;
};

int main(){
#ifndef BAREMETAL
    if (mlockall(MCL_CURRENT | MCL_FUTURE) != 0) {
      perror("mlockall failed");
      exit(1);
    }
#endif

    struct config cin[config_num] __attribute__((aligned(8))) = {
        {0x0800, 0x0000, 0x04}, //
        {0x0100, 0x0000, 0x08}, //
        {0x0800, 0x0000, 0x0c}, //
        {0x0000, 0x0000, 0x18},
        {0x3001, 0x0000, 0x1c},
        {0x0000, 0x0001, 0x20},
        {0x0000, 0x0000, 0x24},
        {0x0001, 0x0000, 0x2c},
        {0x8403, 0x0000, 0x2d},
        {0x0001, 0x0000, 0x30},
        {0x8403, 0x0000, 0x31},
        {0x0000, 0x0000, 0x34},
        {0x8001, 0x0000, 0x35},
        {0x0001, 0x0000, 0x38},
        {0x8803, 0x0000, 0x39},
        {0x0008, 0x0000, 0x40},
        {0x0000, 0x0200, 0x44},
        {0x0000, 0x0200, 0x48},
        {0x0000, 0x0000, 0x4c},
        {0x0001, 0x0000, 0x54},
        {0x8003, 0x0000, 0x55},
        {0x0300, 0x0000, 0x6c},
        {0x0300, 0x0000, 0x70},
        {0x0001, 0x0000, 0x81},
        {0x0001, 0x0000, 0x84},
        {0x8003, 0x0000, 0x85},
        {0x0000, 0x0200, 0x94},
        {0x0000, 0x0200, 0x98},
        {0x0300, 0x0000, 0xbc},
        {0x8000, 0x0000, 0xc0},
        {0x1100, 0x0848, 0xd0}  //
    };
    struct config cout[config_num] __attribute__((aligned(8)));
//    unsigned short cout[config_num*3] __attribute__((aligned(8)));

    int in_addr0 = in_port0 * sizeofBank;
    int in_addr1 = in_port1 * sizeofBank;
    int in_addr2 = in_port2 * sizeofBank;
    int out_addr = out_port * sizeofBank;
    int config_addr = cfg_port * sizeofBank;
//    int spad_addr = 0;
    
    int NUM = 31;
    int len = 4*NUM;
    int config_len = config_num * sizeof(struct config);
    int result;
    unsigned int din0[NUM] __attribute__((aligned(8)));
    unsigned int din1[NUM] __attribute__((aligned(8)));
    unsigned int din2[NUM] __attribute__((aligned(8)));
    unsigned int dout[NUM] __attribute__((aligned(8)));
    
    for(int i = 0; i < NUM; i++){
        din0[i] = i;
        din1[i] = i+1;
        din2[i] = 2*i;
    }
    unsigned int iob_ens = (1 << in_port0) | (1 << in_port1) | (1 << in_port2) | (1 << out_port);

    for(int i = 0; i < 1; i++){
//        printf("Load the input data.\n");
        load(din0, in_addr0, len, i);
        load(din1, in_addr1, len, i);
        load(din2, in_addr2, len, i);
//        fence(0);
//        printf("Load the config information.\n");
        load(cin, config_addr, config_len, i);
//        store(cout, config_addr, config_len, i);
//        printf("Config the CGRA.\n");
//        fence(0);
        config(iob_ens, NUM, config_num, 0, i);
//        printf("Load the input data.\n");
//        load(din, in_addr, len, i);
//        printf("Perform computation.\n");
        execute(i);
//        fence(0);
//        printf("Store the output data.\n");
        store(dout, out_addr, len, i);
//        fence(0);
        printf("Here comes the result: (output)\n");
        for(int i = 0; i < NUM; i++){
            printf("%d\n", dout[i]);
        }
    }
//    //load the data
//    printf("Load the data.\n");
//    load(din, in_addr, len);
//    fence(0);
//    //*************************************check the load***********************************************//
////    store(dout, in_addr, len);
////    fence(0);
////    result = fence(1);
////    printf("Fence succeed? : %d\n", result);
////    printf("Dout : \n");
////    for(int i = 0; i < NUM; i++){
////        printf("0x%x  ", dout[i]);
////    }
////    printf("\n");
//    //****************************************finished**************************************************//
//    printf("Loading data completed.\n---------------------------\n");
//
////    printf("cin address 0x%x\n", (void*)cin);
////    printf("cout address 0x%x\n", (void*)cout);
//    //load the config information
//    printf("Load the config information.\n");
//    load((void*)cin, config_addr, config_len);
//    fence(0);
//    //************************************check the load*************************************************///
//    store((void*)cout, config_addr, config_len);
//    fence(0);
//    //    printf("The size of the config structure is %d.\n", sizeof(struct config));
//    printf("Config data: \n");
//    for (int i = 0; i < config_num; i++){
//    	printf("0x%x, 0x%x, 0x%x\n", cout[i].cfg_data1, cout[i].cfg_data2, cout[i].cfg_base_addr);
////    	printf("(0x%x)\n", ((unsigned short *)cout)[i]);
//    }
//    //***************************************finished***************************************************///
//    printf("Loading config information completed.\n---------------------------\n");
//
//    //config the CGRA
//    printf("Config the CGRA.\n");
//    unsigned int iob_ens = (1 << in_port) | (1 << out_port1) | (1 << out_port2);
//    config(iob_ens, NUM, config_num, 0);
//    fence(0);
//    printf("Configuration completed.\n---------------------------\n");
//
//    //execute
//    printf("Execute the data.\n");
//    execute();
//    result = fence(1);
//    printf("Execution completed.\n---------------------------\n");
//
//    //store the data
//    store(dout1, out_addr1, len);
//    fence(0);
//    store(dout2, out_addr2, len);
//
//    printf("Here comes the result: (output1, output2)\n");
//    for(int i = 0; i < NUM; i++){
//        printf("%d , %d\n", dout1[i], dout2[i]);
//    }
//
//    fence(0);
//    printf("Fence\n");

    return 0;
}
