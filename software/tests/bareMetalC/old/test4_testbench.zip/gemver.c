/**
 * gemver.c: This file is part of the PolyBench/C 3.2 test suite.
 *
 *
 * Contact: Louis-Noel Pouchet <pouchet@cse.ohio-state.edu>
 * Web address: http://polybench.sourceforge.net
 */
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/gemver.h"
#include "include/encoding.h"
#include "include/ISA.h"

int n = N;
DATA_TYPE alpha;
DATA_TYPE beta;
long long unsigned start;
long long unsigned end;
int result;

DATA_TYPE A[N][N];
DATA_TYPE O[N][N];
DATA_TYPE R[N][N];
DATA_TYPE u1[N];
DATA_TYPE v1[N];
DATA_TYPE u2[N];
DATA_TYPE v2[N];

/*POLYBENCH_2D_ARRAY_DECL(A, DATA_TYPE, N, N, n, n);
POLYBENCH_2D_ARRAY_DECL(O, DATA_TYPE, N, N, n, n);
POLYBENCH_2D_ARRAY_DECL(R, DATA_TYPE, N, N, n, n);
POLYBENCH_1D_ARRAY_DECL(u1, DATA_TYPE, N, n);
POLYBENCH_1D_ARRAY_DECL(v1, DATA_TYPE, N, n);
POLYBENCH_1D_ARRAY_DECL(u2, DATA_TYPE, N, n);
POLYBENCH_1D_ARRAY_DECL(v2, DATA_TYPE, N, n);
*/
void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[33][3] __attribute__((aligned(8))) = {
		{0x3000, 0x0000, 0x0008},
		{0x0404, 0x8000, 0x0009},
		{0x0000, 0x0000, 0x000a},
		{0x0610, 0x0101, 0x000b},
		{0x0000, 0x0000, 0x0010},
		{0x0404, 0x8000, 0x0011},
		{0x0000, 0x0000, 0x0012},
		{0x0010, 0x0000, 0x0013},
		{0x3000, 0x0000, 0x0018},
		{0x0404, 0x81ff, 0x0019},
		{0x0000, 0x0000, 0x001a},
		{0x0010, 0x0000, 0x001b},
		{0x2000, 0x0000, 0x0020},
		{0x0404, 0x8000, 0x0021},
		{0x0000, 0x0000, 0x0022},
		{0x0010, 0x0000, 0x0023},
		{0x3000, 0x0000, 0x0028},
		{0x0404, 0x81ff, 0x0029},
		{0x0000, 0x0000, 0x002a},
		{0x0010, 0x0000, 0x002b},
		{0x0000, 0x0000, 0x0030},
		{0x0404, 0x8000, 0x0031},
		{0x0000, 0x0000, 0x0032},
		{0x0010, 0x0000, 0x0033},
		{0x0002, 0x0000, 0x0058},
		{0x0000, 0x0001, 0x0060},
		{0x6800, 0x0000, 0x0068},
		{0x0000, 0x0001, 0x0070},
		{0x1400, 0x0000, 0x0078},
		{0x9101, 0x0000, 0x00a9},
		{0x4803, 0x0000, 0x00b1},
		{0x5101, 0x0000, 0x00b9},
		{0x4803, 0x0000, 0x00c1},
	};

	load_cfg(cin, 0x40000, 198, 0, 0);
	load_data(din_addr[0], 0x8000, 16384, 0, 0);
	load_data(din_addr[1], 0x10000, 256, 0, 0);
	load_data(din_addr[2], 0x14000, 256, 0, 0);
	load_data(din_addr[3], 0x0, 256, 0, 0);
	load_data(din_addr[4], 0xc000, 256, 0, 0);
	config(0x0, 33, 0, 0);
	execute(0x3f, 0, 0);
	store(dout_addr[0], 0x4000, 16384, 0, 0);
	result = fence(1);
}

/* Array initialization. */
static
void init_array ()
{
  int i, j;

  alpha = 43532;
  beta = 12313;

  for (i = 0; i < n; i++)
    {
      u1[i] = i;
      u2[i] = (i+1)/n/2;
      v1[i] = (i+1)/n/4;
      v2[i] = (i+1)/n/6;
      for (j = 0; j < n; j++)
      {
	       A[i][j] = ((DATA_TYPE) i*j) / n;
      }
    }
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_gemver()
{
  int i, j;

  for (i = 0; i < _PB_N; i++)
  {
    for (j = 0; j < _PB_N; j++)
    {
      O[i][j] = A[i][j] + u1[i] * v1[j] + u2[i] * v2[j];
    }
  }
}

static
void result_check()
{
  int i, j;

  for (i = 0; i < _PB_N; i++)
  {
    for (j = 0; j < _PB_N; j++)
    {
      if (O[i][j] != R[i][j]) printf("There is an error in location (%d, %d)\n", i, j);
    }
  }
}


int main(int argc, char** argv)
{
  printf("The number of N is %d", N);
  init_array();
  printf("Initialization finished!\n");
  start = rdcycle();
  /* Run kernel. */
  kernel_gemver();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  void* cgra_din_addr[5] = {A, u1, v1, u2, v2};
  void* cgra_dout_addr[1] = {R};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();

  result_check();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);

/*  POLYBENCH_FREE_ARRAY(A);
  POLYBENCH_FREE_ARRAY(O);
  POLYBENCH_FREE_ARRAY(R);
  POLYBENCH_FREE_ARRAY(u1);
  POLYBENCH_FREE_ARRAY(v1);
  POLYBENCH_FREE_ARRAY(u2);
  POLYBENCH_FREE_ARRAY(v2);
  */
  return 0;
}