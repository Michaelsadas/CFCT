#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define TYPE int
#define col_size 32
#define row_size 32
#define f_size 9

TYPE orig[row_size * col_size]; 
TYPE sol[row_size * col_size]; 
TYPE filter[f_size];
TYPE res[row_size * col_size]; 

long long unsigned start;
long long unsigned end;
int result;

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[51][3] __attribute__((aligned(8))) = {
		{0x0000, 0x3000, 0x0008},
		{0x0400, 0x3c00, 0x0009},
		{0x0180, 0x0780, 0x000a},
		{0x0910, 0x0101, 0x000b},
		{0x0003, 0x0000, 0x0058},
		{0x0000, 0x0020, 0x00e8},
		{0x0000, 0x0020, 0x0178},
		{0x0000, 0x0000, 0x0208},
		{0x180f, 0x0000, 0x0251},
		{0x0000, 0x8002, 0x0252},
		{0x0183, 0x7080, 0x0253},
		{0x0000, 0x0000, 0x0254},
		{0x0030, 0x0000, 0x0298},
		{0x0000, 0x0000, 0x0328},
		{0x2021, 0x0001, 0x0371},
		{0x0003, 0x0000, 0x03c0},
		{0xe101, 0x0000, 0x0409},
		{0x0040, 0x0000, 0x0450},
		{0x0002, 0x0000, 0x0458},
		{0x0000, 0x0001, 0x0460},
		{0x1803, 0x0001, 0x0491},
		{0x1803, 0x0001, 0x0499},
		{0x2003, 0x0001, 0x04a9},
		{0x0010, 0x0000, 0x04d8},
		{0x0010, 0x0000, 0x04e0},
		{0x0000, 0x0000, 0x04e8},
		{0x0004, 0x0000, 0x04f8},
		{0x0000, 0x3004, 0x0518},
		{0x0400, 0x3dff, 0x0519},
		{0xe180, 0x07bf, 0x051a},
		{0x0010, 0x0000, 0x051b},
		{0x1000, 0x3004, 0x0520},
		{0x0400, 0x3dff, 0x0521},
		{0xe180, 0x07bf, 0x0522},
		{0x0010, 0x0000, 0x0523},
		{0x6000, 0x3000, 0x0528},
		{0xe800, 0x3dff, 0x0529},
		{0xfd00, 0x07bf, 0x052a},
		{0x0010, 0x0000, 0x052b},
		{0x7000, 0x3000, 0x0530},
		{0xe800, 0x3dff, 0x0531},
		{0xfd00, 0x07bf, 0x0532},
		{0x0010, 0x0000, 0x0533},
		{0x6001, 0x3000, 0x0538},
		{0xe800, 0x3dff, 0x0539},
		{0xfd00, 0x07bf, 0x053a},
		{0x0010, 0x0000, 0x053b},
		{0x1001, 0x3004, 0x0540},
		{0x0400, 0x3dff, 0x0541},
		{0xe180, 0x07bf, 0x0542},
		{0x0010, 0x0000, 0x0543},
	};

	load_cfg(cin, 0x40000, 306, 0, 0);
	load_data(din_addr[0], 0x28000, 28, 0, 0);
	load_data(din_addr[1], 0x20000, 4088, 0, 0);
	load_data(din_addr[2], 0x30000, 32, 0, 0);
	load_data(din_addr[3], 0x34000, 4092, 0, 0);
	load_data(din_addr[4], 0x2c000, 28, 0, 0);
	load_data(din_addr[5], 0x24000, 4088, 0, 0);
	config(0x0, 51, 0, 0);
	execute(0x3f01, 0, 0);
	store(dout_addr[0], 0x0, 3832, 0, 0);
	result = fence(1); 
}

/* Array initialization. */
static
void init_array()
{
  	int i, j;

  	for (i = 0; i < f_size; i++)
    {
      	filter[i] = i;
    }
	for (i = 0; i < row_size * col_size; i++)
	{
		orig[i] = i;
	}
}


void stencil2d (){
    int r, c, k1, k2;
    TYPE temp, mul;

    for (r=0; r<row_size-2; r++) {
        for (c=0; c<col_size-2; c++) {
            temp = (TYPE)0;
            for (k1=0;k1<3;k1++){
                for (k2=0;k2<3;k2++){
                    mul = filter[k1*3 + k2] * orig[(r+k1)*col_size + c+k2];
                    temp += mul;
                }
            }
            sol[(r*col_size) + c] = temp;
        }
    }
}


static
void result_check()
{
  	int i, j, r, c;

    for (r=0; r<row_size-2; r++) {
        for (c=0; c<col_size-2; c++) {
    		if (res[(r*col_size) + c] != sol[(r*col_size) + c]) printf("There is an error in location (%d)[%d, %d]\n", i, res[(r*col_size) + c], sol[(r*col_size) + c]);
  		}
	}
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[6] = {filter, orig, filter, (void*)orig+8, (void*)filter+8, (void*)orig+24};
  void* cgra_dout_addr[1] = {res};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  stencil2d();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}