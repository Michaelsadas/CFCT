#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define N 1024
//int *a;
int a[N];
int b[N];
int c[N];

long long unsigned start;
long long unsigned end;
int result;

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[20][3] __attribute__((aligned(8))) = {
		{0x2000, 0xf000, 0x0020},
		{0x003f, 0x0000, 0x0021},
		{0x0000, 0x0000, 0x0022},
		{0x0510, 0x0101, 0x0023},
		{0x2000, 0xf000, 0x0028},
		{0x003f, 0x0000, 0x0029},
		{0x0000, 0x0000, 0x002a},
		{0x0010, 0x0000, 0x002b},
		{0x3001, 0xf000, 0x0030},
		{0x003f, 0x0000, 0x0031},
		{0x0000, 0x0000, 0x0032},
		{0x0010, 0x0000, 0x0033},
		{0x0000, 0x0000, 0x0070},
		{0x6000, 0x0000, 0x0078},
		{0x0000, 0x0001, 0x0080},
		{0x9001, 0x0000, 0x00b9},
		{0x000a, 0x0000, 0x00c0},
		{0x0803, 0x0000, 0x00c1},
		{0x0014, 0x0000, 0x00c8},
		{0x0803, 0x0000, 0x00c9},
	};

	load_cfg(cin, 0x40000, 120, 0, 0);
	load_data(din_addr[0], 0x10000, 4092, 0, 0);
	load_data(din_addr[1], 0x14000, 4096, 0, 0);
	config(0x0, 20, 0, 0);
	execute(0x38, 0, 0);
	result = fence(1);
}

/* Array initialization. */
static
void init_array()
{
    int i;
    for (i = 0; i < N; i++) {
        a[i] = i;
    }    
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
__attribute__((noinline))
void conv2(){
  int i;
for (i = 0; i < N-1; i++) {
        //DFGLoop: loop
#ifdef CGRA_COMPILER
please_map_me();
#endif 
        b[i] = a[i] * 10 + a[i + 1] * 20; //+ a[i+ 2] * 3;
    }
}

static
void result_check()
{
  int i, j;

  for (i = 0; i < N; i++)
  {
    if (c[i] != b[i]) printf("There is an error in location (%d)[%d, %d]\n", i, c[i], b[i]);
  }
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[2] = {a, a};
  void* cgra_dout_addr[1] = {c};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  /* Run kernel. */
  conv2();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}