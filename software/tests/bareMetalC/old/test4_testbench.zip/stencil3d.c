#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define height_size 8
#define col_size 8
#define row_size 16
//Data Bounds
#define TYPE int
#define MAX 1000
#define MIN 1
//Convenience Macros
#define SIZE (row_size * col_size * height_size)
#define INDX(_row_size,_col_size,_i,_j,_k) ((_i)+_row_size*((_j)+_col_size*(_k)))

TYPE C[2]; 
TYPE orig[SIZE]; 
TYPE sol[SIZE];
TYPE res[SIZE];

long long unsigned start;
long long unsigned end;
int result;

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[65][3] __attribute__((aligned(8))) = {
		{0x1000, 0xe000, 0x0028},
		{0x0000, 0x0c00, 0x0029},
		{0x0000, 0x0180, 0x002a},
		{0x0010, 0x0000, 0x002b},
		{0x2001, 0xe000, 0x0030},
		{0x0c00, 0x0c00, 0x0031},
		{0x1180, 0x0180, 0x0032},
		{0x0010, 0x0000, 0x0033},
		{0x0400, 0x0000, 0x0078},
		{0x4803, 0x0000, 0x00c1},
		{0x0000, 0x0000, 0x0110},
		{0x0000, 0x0600, 0x01a0},
		{0x0000, 0x0600, 0x0230},
		{0x0000, 0x3000, 0x02c0},
		{0x0000, 0x6000, 0x0350},
		{0x0000, 0x0600, 0x03e0},
		{0x2001, 0x0001, 0x03f9},
		{0x000c, 0x0000, 0x0448},
		{0x0200, 0x0000, 0x0450},
		{0x0c00, 0x0000, 0x0470},
		{0x1801, 0x0001, 0x0491},
		{0x0a01, 0x0001, 0x0499},
		{0x1b01, 0x0001, 0x04a1},
		{0x1c01, 0x0001, 0x04a9},
		{0xe083, 0x0000, 0x04b1},
		{0x5a01, 0x0000, 0x04b9},
		{0x0010, 0x0000, 0x04d8},
		{0x0000, 0x0000, 0x04e0},
		{0x0000, 0x0000, 0x04e8},
		{0x0000, 0x0000, 0x04f0},
		{0x0000, 0x0000, 0x04f8},
		{0x0000, 0x0000, 0x0500},
		{0x0000, 0x0000, 0x0508},
		{0x2000, 0xe000, 0x0518},
		{0x0c00, 0x0c00, 0x0519},
		{0x1180, 0x0180, 0x051a},
		{0x0010, 0x0000, 0x051b},
		{0x3001, 0xe000, 0x0520},
		{0x0c00, 0x0c00, 0x0521},
		{0x1180, 0x0180, 0x0522},
		{0x0010, 0x0000, 0x0523},
		{0x2001, 0xe000, 0x0528},
		{0x0c00, 0x0c00, 0x0529},
		{0x1180, 0x0180, 0x052a},
		{0x0010, 0x0000, 0x052b},
		{0x3001, 0xe000, 0x0530},
		{0x0c00, 0x0c00, 0x0531},
		{0x1180, 0x0180, 0x0532},
		{0x0010, 0x0000, 0x0533},
		{0x2000, 0xe000, 0x0538},
		{0x0c00, 0x0c00, 0x0539},
		{0x1180, 0x0180, 0x053a},
		{0x0010, 0x0000, 0x053b},
		{0x3000, 0xe000, 0x0540},
		{0x0c00, 0x0c00, 0x0541},
		{0x1180, 0x0180, 0x0542},
		{0x0010, 0x0000, 0x0543},
		{0x0000, 0xe000, 0x0548},
		{0x0000, 0x0c00, 0x0549},
		{0x0000, 0x0180, 0x054a},
		{0x0110, 0x0000, 0x054b},
		{0x3001, 0xe000, 0x0550},
		{0x0c00, 0x0c00, 0x0551},
		{0x1180, 0x0180, 0x0552},
		{0x0a10, 0x0001, 0x0553},
	};

	load_cfg(cin, 0x40000, 390, 0, 0);
	load_data(din_addr[0], 0x10000, 2940, 0, 0);
	load_data(din_addr[1], 0x28000, 2940, 0, 0);
	load_data(din_addr[2], 0x20000, 2932, 0, 0);
	load_data(din_addr[3], 0x24000, 2940, 0, 0);
	load_data(din_addr[4], 0x2c000, 2940, 0, 0);
	load_data(din_addr[5], 0x30000, 2936, 0, 0);
	load_data(din_addr[6], 0x34000, 2936, 0, 0);
	load_data(din_addr[7], 0x14000, 4, 0, 0);
	load_data(din_addr[8], 0x38000, 8, 0, 0);
	config(0x0, 65, 0, 0);
	execute(0xff30, 0, 0);
	store(dout_addr[0], 0x3c000, 2940, 0, 0);
	result = fence(1); 
}

/* Array initialization. */
static
void init_array()
{
	int i, j, k;
    for(j=0; j<col_size; j++) {
        for(k=0; k<row_size; k++) {
            sol[INDX(row_size, col_size, k, j, 0)] = orig[INDX(row_size, col_size, k, j, 0)];
            sol[INDX(row_size, col_size, k, j, height_size-1)] = orig[INDX(row_size, col_size, k, j, height_size-1)];
        }
    }
    for(i=1; i<height_size-1; i++) {
        for(k=0; k<row_size; k++) {
            sol[INDX(row_size, col_size, k, 0, i)] = orig[INDX(row_size, col_size, k, 0, i)];
            sol[INDX(row_size, col_size, k, col_size-1, i)] = orig[INDX(row_size, col_size, k, col_size-1, i)];
        }
    }
    for(i=1; i<height_size-1; i++) {
        for(j=1; j<col_size-1; j++) {
            sol[INDX(row_size, col_size, 0, j, i)] = orig[INDX(row_size, col_size, 0, j, i)];
            sol[INDX(row_size, col_size, row_size-1, j, i)] = orig[INDX(row_size, col_size, row_size-1, j, i)];
        }
    }
	C[0] = 1;
	C[1] = 2;
}


void stencil3d (){
    int i,j,k;
	int sum0, sum1, mul0, mul1;

	for(i = 1; i < height_size - 1; i++){
        for(j = 1; j < col_size - 1; j++){
            for(k = 1; k < row_size - 1; k++){
            
                sum0 = orig[INDX(row_size, col_size, k, j, i)];
                sum1 = orig[INDX(row_size, col_size, k, j, i + 1)] +
                       orig[INDX(row_size, col_size, k, j, i - 1)] +
                       orig[INDX(row_size, col_size, k, j + 1, i)] +
                       orig[INDX(row_size, col_size, k, j - 1, i)] +
                       orig[INDX(row_size, col_size, k + 1, j, i)] +
                       orig[INDX(row_size, col_size, k - 1, j, i)];
                mul0 = sum0 * C[0];
                mul1 = sum1 * C[1];
                sol[INDX(row_size, col_size, k, j, i)] = mul0 + mul1;
            }
        }
    }
}


static
void result_check()
{
  	int i, j, k, r, c;
	for(i = 1; i < height_size - 1; i++){
        for(j = 1; j < col_size - 1; j++){
            for(k = 1; k < row_size - 1; k++){
    		if (res[INDX(row_size, col_size, k, j, i)] != sol[INDX(row_size, col_size, k, j, i)]) printf("There is an error in location (%d)[%d, %d]\n", i, res[INDX(row_size, col_size, k, j, i)], sol[INDX(row_size, col_size, k, j, i)]);
  			}
		}
	}
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[9] = {(void*)orig+576, (void*)orig+1600, orig, (void*)orig+704, (void*)orig+448, (void*)orig+584, (void*)orig+568, C, C};
  void* cgra_dout_addr[1] = {(void*)res+576};
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  stencil3d();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}