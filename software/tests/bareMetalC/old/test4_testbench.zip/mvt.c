#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define POLYBENCH_USE_SCALAR_LB
#define N 20
#define _PB_N 20
#define int_IS_INT

int n = N;
int alpha;
int beta;
long long unsigned start;
long long unsigned end;
int result;

int A[N][N];
int x1[N];
int x2[N];
int y_1[N];
int y_2[N];

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[28][3] __attribute__((aligned(8))) = {
		{0x1000, 0x4000, 0x0008},
		{0x0401, 0x2800, 0x0009},
		{0x0000, 0x0000, 0x000a},
		{0x0810, 0x0101, 0x000b},
		{0x0000, 0x4000, 0x0010},
		{0x0401, 0x2800, 0x0011},
		{0x0000, 0x0000, 0x0012},
		{0x0010, 0x0000, 0x0013},
		{0x3000, 0x4000, 0x0018},
		{0xb401, 0x29ff, 0x0019},
		{0x0000, 0x0000, 0x001a},
		{0x0010, 0x0000, 0x001b},
		{0x2000, 0x4000, 0x0020},
		{0x0401, 0x2800, 0x0021},
		{0x0000, 0x0000, 0x0022},
		{0x0010, 0x0000, 0x0023},
		{0x0002, 0x0000, 0x0058},
		{0x0000, 0x0001, 0x0060},
		{0x0400, 0x0000, 0x0068},
		{0x0881, 0x0001, 0x00a9},
		{0x4803, 0x0000, 0x00b1},
		{0x000c, 0x0200, 0x00f8},
		{0x0000, 0x0620, 0x0188},
		{0x0300, 0x0000, 0x0218},
		{0x080f, 0x0000, 0x0261},
		{0x0000, 0x8002, 0x0262},
		{0x0a02, 0x0280, 0x0263},
		{0x0000, 0x0000, 0x0264},
	};

	load_cfg(cin, 0x40000, 168, 0, 0);
	load_data(din_addr[0], 0x8000, 1600, 0, 0);
	load_data(din_addr[1], 0xc000, 80, 0, 0);
	load_data(din_addr[2], 0x0, 80, 0, 0);
	config(0x0, 28, 0, 0);
	execute(0xf, 0, 0);
	store(dout_addr[0], 0x4000, 80, 0, 0);
	result = fence(1);
}

/* Array initialization. */
static
void init_array()
{
  int i, j;

  for (i = 0; i < n; i++)
    {
      x1[i] = (int) (i % n) / n; 
      x2[i] = (int) ((i + 1) % n) / n;
      y_1[i] = (int) ((i + 3) % n) / n;
      y_2[i] = (int) ((i + 4) % n) / n;
      for (j = 0; j < n; j++)
	A[i][j] = (int) (i*j % n) / n;
    }
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
static
void kernel_mvt()
{
  int i, j ,s;

  for (i = 0; i < _PB_N; i++)
  {
    s = 0;
    for (j = 0; j < _PB_N; j++)
    {
      //s = x1[i];
      s += A[i][j] * y_1[j];
      //x1[i] = s;
    }
    x1[i] += s;
  }
}

static
void result_check()
{
  int i, j;

  for (i = 0; i < _PB_N; i++)
  {
    if (x1[i] != x2[i]) printf("There is an error in location (%d)\n", i);
  }
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[3] = {A, y_1, x1};
  void* cgra_dout_addr[1] = {x2};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  /* Run kernel. */
  kernel_mvt();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}