#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define N 1024
//int *a;
int a[N];
int b[N];
int c[N];

long long unsigned start;
long long unsigned end;
int result;

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[30][3] __attribute__((aligned(8))) = {
		{0x2001, 0xe000, 0x0028},
		{0x003f, 0x0000, 0x0029},
		{0x0000, 0x0000, 0x002a},
		{0x0010, 0x0000, 0x002b},
		{0x3000, 0xe000, 0x0030},
		{0x003f, 0x0000, 0x0031},
		{0x0000, 0x0000, 0x0032},
		{0x0010, 0x0000, 0x0033},
		{0x2000, 0xe000, 0x0038},
		{0x003f, 0x0000, 0x0039},
		{0x0000, 0x0000, 0x003a},
		{0x0010, 0x0000, 0x003b},
		{0x3000, 0xe000, 0x0040},
		{0x003f, 0x0000, 0x0041},
		{0x0000, 0x0000, 0x0042},
		{0x0610, 0x0001, 0x0043},
		{0x0000, 0x0000, 0x0078},
		{0x0000, 0x0000, 0x0080},
		{0x0030, 0x0000, 0x0088},
		{0x0014, 0x0000, 0x00c0},
		{0x0803, 0x0000, 0x00c1},
		{0x0003, 0x0000, 0x00c8},
		{0x0803, 0x0000, 0x00c9},
		{0x000a, 0x0000, 0x00d0},
		{0x0803, 0x0000, 0x00d1},
		{0x0000, 0x0000, 0x0110},
		{0x0000, 0x0000, 0x0118},
		{0x8801, 0x0000, 0x0159},
		{0x5901, 0x0000, 0x0161},
		{0x0000, 0x0000, 0x01a8},
	};

	load_cfg(cin, 0x40000, 180, 0, 0);
	load_data(din_addr[0], 0x18000, 4088, 0, 0);
	load_data(din_addr[1], 0x10000, 4092, 0, 0);
	load_data(din_addr[2], 0x14000, 4088, 0, 0);
	config(0x0, 30, 0, 0);
	execute(0xf0, 0, 0);
	store(dout_addr[0], 0x1c000, 4088, 0, 0);
	result = fence(1);
}

/* Array initialization. */
static
void init_array()
{
    int i;
    for (i = 0; i < N; i++) {
        a[i] = i;
    }    
}


/* Main computational kernel. The whole function will be timed,
   including the call and return. */
__attribute__((noinline))
void conv3(){
  int i;
    for (i = 0; i < N-2; i++) {
        //DFGLoop: loop
#ifdef CGRA_COMPILER
please_map_me();
#endif 
        b[i] = a[i] * 10 + a[i + 1] * 20 + a[i+ 2] * 3;
        /*int a_0 = a[i+2];
        b[i] = a_2 * 1 + a_1 * 2 + a_0 * 3;
        a_2 = a_1;
        a_1 = a_0;
        */
    }
}

static
void result_check()
{
  int i, j;

  for (i = 0; i < N; i++)
  {
    if (c[i] != b[i]) printf("There is an error in location (%d)[%d, %d]\n", i, c[i], b[i]);
  }
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[3] = {a, a, (void*)a+8};
  void* cgra_dout_addr[1] = {c};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  /* Run kernel. */
  conv3();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}