#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <math.h>

/* Include polybench common header. */
#include "include/polybench.h"

/* Include benchmark-specific header. */
/* Default data type is double, default size is 4000. */
#include "include/encoding.h"
#include "include/ISA.h"

#define SIZE  32

typedef struct Acceleration Acceleration;
struct Acceleration {
    int x;
    int y;
    int z;
};

unsigned char second = 0;
unsigned char minute = 0;
unsigned char hour = 0;
unsigned char state = 0;
unsigned char I1_flag = 0;
unsigned char I2_flag = 0;
unsigned char timerFlag1 = 0;
unsigned char timerFlag2 = 0;
unsigned char aux=0;
char Int_SourceSystem =0;
char Int_SourceTrans=0;
unsigned char length;
char buffer[14];
int step[SIZE]={};
int km[SIZE]={};
int acc_vector[SIZE];
int res_vector[SIZE];

int i;
int sub_x;
int sub_y;
int sub_z;
int acceleration_x[SIZE];
int acceleration_y[SIZE];
int acceleration_z[SIZE];
int acc_avg_x[SIZE];
int acc_avg_y[SIZE];
int acc_avg_z[SIZE];

long long unsigned start;
long long unsigned end;
int result;

void cgra_execute(void** din_addr, void** dout_addr)
{
	unsigned short int cin[71][3] __attribute__((aligned(8))) = {
		{0x8000, 0x8000, 0x0008},
		{0x9000, 0x41ff, 0x0009},
		{0x0000, 0x0000, 0x000a},
		{0x0010, 0x0000, 0x000b},
		{0x9001, 0x8000, 0x0010},
		{0x9000, 0x41ff, 0x0011},
		{0x0000, 0x0000, 0x0012},
		{0x0010, 0x0000, 0x0013},
		{0x9001, 0x8000, 0x0018},
		{0x9000, 0x41ff, 0x0019},
		{0x0000, 0x0000, 0x001a},
		{0x0010, 0x0000, 0x001b},
		{0x8000, 0x8000, 0x0020},
		{0x9000, 0x41ff, 0x0021},
		{0x0000, 0x0000, 0x0022},
		{0x0010, 0x0000, 0x0023},
		{0x9001, 0x8000, 0x0028},
		{0x9000, 0x41ff, 0x0029},
		{0x0000, 0x0000, 0x002a},
		{0x0010, 0x0000, 0x002b},
		{0x8001, 0x8000, 0x0030},
		{0x9000, 0x41ff, 0x0031},
		{0x0000, 0x0000, 0x0032},
		{0x0010, 0x0000, 0x0033},
		{0x9000, 0x8000, 0x0038},
		{0x9000, 0x41ff, 0x0039},
		{0x0000, 0x0000, 0x003a},
		{0x0010, 0x0000, 0x003b},
		{0x8000, 0x8000, 0x0040},
		{0x9000, 0x41ff, 0x0041},
		{0x0000, 0x0000, 0x0042},
		{0x0010, 0x0000, 0x0043},
		{0x0000, 0x0000, 0x0058},
		{0x0400, 0x0008, 0x0060},
		{0x0900, 0x0000, 0x0068},
		{0x0000, 0x0030, 0x0070},
		{0x0400, 0x0002, 0x0078},
		{0x0000, 0x0002, 0x0080},
		{0x0400, 0x0001, 0x0088},
		{0x4803, 0x0000, 0x00a9},
		{0x4823, 0x0000, 0x00b1},
		{0x4803, 0x0000, 0x00c1},
		{0x4803, 0x0000, 0x00d1},
		{0x0000, 0x0200, 0x00f0},
		{0x3000, 0x0000, 0x00f8},
		{0x2000, 0x0003, 0x0100},
		{0x0000, 0x0000, 0x0108},
		{0x9001, 0x0000, 0x0139},
		{0xd001, 0x0000, 0x0141},
		{0x0300, 0x0000, 0x0180},
		{0x0000, 0x0000, 0x0188},
		{0x8841, 0x0000, 0x01c9},
		{0x0100, 0x0000, 0x0210},
		{0x080f, 0x0000, 0x0259},
		{0x0000, 0x0002, 0x025a},
		{0x0404, 0x0400, 0x025b},
		{0x0000, 0x0000, 0x025c},
		{0x0000, 0x1000, 0x02a0},
		{0x0000, 0x6000, 0x0330},
		{0x0000, 0x0600, 0x03c0},
		{0x0c00, 0x0000, 0x0450},
		{0x5881, 0x0000, 0x0499},
		{0x0110, 0x0000, 0x04e0},
		{0x0000, 0x8000, 0x0520},
		{0x0400, 0x4000, 0x0521},
		{0x0000, 0x0000, 0x0522},
		{0x0310, 0x0000, 0x0523},
		{0x0000, 0x8000, 0x0528},
		{0x0400, 0x4000, 0x0529},
		{0x0000, 0x0000, 0x052a},
		{0x0b10, 0x0001, 0x052b},
	};

	load_cfg(cin, 0x40000, 426, 0, 0);
	load_data(din_addr[0], 0x0, 116, 0, 0);
	load_data(din_addr[1], 0x8000, 116, 0, 0);
	load_data(din_addr[2], 0x10000, 120, 0, 0);
	load_data(din_addr[3], 0x14000, 120, 0, 0);
	load_data(din_addr[4], 0x18000, 116, 0, 0);
	load_data(din_addr[5], 0x1c000, 116, 0, 0);
	load_data(din_addr[6], 0xc000, 120, 0, 0);
	load_data(din_addr[7], 0x4000, 120, 0, 0);
	load_data(din_addr[8], 0x20000, 128, 0, 0);
	config(0x0, 71, 0, 0);
	execute(0x6ff, 0, 0);
	store(dout_addr[0], 0x28000, 128, 0, 0);
	result = fence(1); 
}

/* Array initialization. */
static
void init_array()
{
	for(int i=0;i<SIZE;i++){    
    	sub_x = 0;
    	sub_y = 0;
    	sub_z = 0;

    	acceleration_x[i] = 3*i;
    	acceleration_y[i] = 3*i+1;
    	acceleration_z[i] = 3*i+2;
    
    	acc_avg_x[i] = i;
    	acc_avg_y[i] = i;
    	acc_avg_z[i] = i;
 	}
}


__attribute__((noinline))
void pedometer(){//(int input[], int output[], int coefficients[])
	for(int i=0;i<SIZE;i++){
		acc_vector[i] = (acceleration_x[i]- acc_avg_x[i]) * (acceleration_x[i]- acc_avg_x[i])+  (acceleration_y[i]- acc_avg_y[i]) * (acceleration_y[i]- acc_avg_y[i])+ (acceleration_z[i]-acc_avg_z[i]) * (acceleration_z[i]-acc_avg_z[i]) ;
	}
}

static
void result_check()
{
  int i, j;

  for (i = 0; i < SIZE; i++)
  {
    if (acc_vector[i] != res_vector[i]) printf("There is an error in location (%d)[%d, %d]\n", i, acc_vector[i], res_vector[i]);
  }
}


int main(int argc, char** argv)
{
  init_array();
  printf("Initialization finished!\n");

  void* cgra_din_addr[6] = {acceleration_x, acc_avg_x, acceleration_y, acc_avg_y, acceleration_z, acc_avg_z};
  void* cgra_dout_addr[1] = {res_vector};
  start = rdcycle();
  cgra_execute(cgra_din_addr, cgra_dout_addr);
  end = rdcycle();
  printf("It takes %d cycles for CGRA to finish the task(%d).\n", end - start, result);
  
  start = rdcycle();
  /* Run kernel. */
  pedometer();
  end = rdcycle();
  printf("It takes %d cycles for CPU to finish the task.", end - start);

  result_check();
  printf("Done!\n");

  return 0;
}